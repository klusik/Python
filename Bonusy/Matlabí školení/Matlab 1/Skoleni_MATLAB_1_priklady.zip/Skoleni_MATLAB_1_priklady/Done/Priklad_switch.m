s = input('Zadej pribuzneho: ','s');

switch s
    
    case 'otec'
        disp('Je rodic.')
    case 'matka'
        disp('Je rodic.')
    otherwise
        disp('Neni rodic.')
end