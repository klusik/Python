%%  Grafy funkci
%
%    - sinus
 
%% priprava dat
x = 0:pi/20:2*pi;
y = sin(x);

%%
figure    % nove graficke okno
plot(x,y) % vykresleni grafu
