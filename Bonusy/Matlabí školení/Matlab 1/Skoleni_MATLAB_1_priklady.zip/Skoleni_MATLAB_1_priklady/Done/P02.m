t = 0:pi/20:50*pi;

x = t.*cos(t);
y = t.*sin(t);
z = t;

plot3(x,y,z)

grid