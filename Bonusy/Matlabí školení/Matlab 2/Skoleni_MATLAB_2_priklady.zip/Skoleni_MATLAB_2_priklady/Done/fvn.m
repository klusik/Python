function fvn

x = 5;
vnorena(1)
disp(x)
vnorena(2)
disp(x)
 
    function vnorena(a)
        x = x+a;
    end
end


