function [A,B,C] = moje_funkce(a,b,c)

%JMF1   Pokusna funkce
%   JMF1(a,b,c)

x1 = a;
x2 = b;

A = x1+x2;
B = c;
C = A+B;

end

